ESP32-MPU6050
====================

This is a interface of esp32 with accelerometer mpu6050 over I2C
